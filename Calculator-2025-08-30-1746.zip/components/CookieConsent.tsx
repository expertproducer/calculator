'use client'

import { useState, useEffect } from 'react'
import { Cookie, Settings, X, CheckCircle, AlertTriangle, Info } from 'lucide-react'
import { initializeGTM, sendConsentEvent } from '@/lib/gtm'

interface CookiePreferences {
  essential: boolean
  analytics: boolean
  marketing: boolean
  functional: boolean
}

export default function CookieConsent({ locale = 'en' }: { locale?: string }) {
  const [showBanner, setShowBanner] = useState(false)
  const [showPreferences, setShowPreferences] = useState(false)
  const [preferences, setPreferences] = useState<CookiePreferences>({
    essential: true,
    analytics: false,
    marketing: false,
    functional: false
  })

  const localeTyped = (locale === 'de' ? 'de' : locale === 'fr' ? 'fr' : 'en') as 'en' | 'de' | 'fr'
  
  const translations = {
    en: {
      title: "We use cookies to enhance your experience",
      description: "We use cookies and similar technologies to help personalize content, provide social media features, and analyze our traffic. We also share information about your use of our site with our social media, advertising, and analytics partners.",
      acceptAll: "Accept All",
      decline: "Decline",
      preferences: "Preferences",
      preferencesTitle: "Cookie Preferences",
      essential: "Essential Cookies",
      analytics: "Analytics Cookies",
      marketing: "Marketing Cookies",
      functional: "Functional Cookies",
      alwaysActive: "Always Active",
      savePreferences: "Save Preferences",
      cancel: "Cancel",
      essentialDesc: "These cookies are necessary for the website to function and cannot be disabled.",
      analyticsDesc: "Help us understand how visitors interact with our website by collecting and reporting information anonymously.",
      marketingDesc: "Used to track visitors across websites to display relevant and engaging advertisements.",
      functionalDesc: "Enable enhanced functionality and personalization such as chat support and social media integration."
    },
    de: {
      title: "Wir verwenden Cookies, um Ihre Erfahrung zu verbessern",
      description: "Wir verwenden Cookies und ähnliche Technologien, um Inhalte zu personalisieren, Social-Media-Funktionen bereitzustellen und unseren Traffic zu analysieren. Wir teilen auch Informationen über Ihre Nutzung unserer Website mit unseren Social-Media-, Werbe- und Analytics-Partnern.",
      acceptAll: "Alle akzeptieren",
      decline: "Ablehnen",
      preferences: "Einstellungen",
      preferencesTitle: "Cookie-Einstellungen",
      essential: "Wesentliche Cookies",
      analytics: "Analytics-Cookies",
      marketing: "Marketing-Cookies",
      functional: "Funktionale Cookies",
      alwaysActive: "Immer aktiv",
      savePreferences: "Einstellungen speichern",
      cancel: "Abbrechen",
      essentialDesc: "Diese Cookies sind für das Funktionieren der Website erforderlich und können nicht deaktiviert werden.",
      analyticsDesc: "Helfen uns zu verstehen, wie Besucher mit unserer Website interagieren, indem sie Informationen anonym sammeln und melden.",
      marketingDesc: "Werden verwendet, um Besucher über Websites hinweg zu verfolgen und relevante und ansprechende Werbung anzuzeigen.",
      functionalDesc: "Ermöglichen erweiterte Funktionalität und Personalisierung wie Chat-Support und Social-Media-Integration."
    },
    fr: {
      title: "Nous utilisons des cookies pour améliorer votre expérience",
      description: "Nous utilisons des cookies et des technologies similaires pour aider à personnaliser le contenu, fournir des fonctionnalités de médias sociaux et analyser notre trafic. Nous partageons également des informations sur votre utilisation de notre site avec nos partenaires de médias sociaux, de publicité et d'analyse.",
      acceptAll: "Tout accepter",
      decline: "Refuser",
      preferences: "Préférences",
      preferencesTitle: "Préférences des cookies",
      essential: "Cookies essentiels",
      analytics: "Cookies analytiques",
      marketing: "Cookies marketing",
      functional: "Cookies fonctionnels",
      alwaysActive: "Toujours actif",
      savePreferences: "Sauvegarder les préférences",
      cancel: "Annuler",
      essentialDesc: "Ces cookies sont nécessaires au fonctionnement du site web et ne peuvent pas être désactivés.",
      analyticsDesc: "Nous aident à comprendre comment les visiteurs interagissent avec notre site web en collectant et rapportant des informations de manière anonyme.",
      marketingDesc: "Utilisés pour suivre les visiteurs sur les sites web afin d'afficher des publicités pertinentes et engageantes.",
      functionalDesc: "Permettent une fonctionnalité améliorée et la personnalisation comme le support de chat et l'intégration des médias sociaux."
    }
  }[localeTyped]

  useEffect(() => {
    // Проверяем, есть ли уже согласие
    const consent = localStorage.getItem('cookie-consent')
    if (!consent) {
      setShowBanner(true)
    } else {
      const savedPrefs = JSON.parse(consent)
      setPreferences(savedPrefs)
      applyConsent(savedPrefs)
    }

    // Слушаем событие открытия настроек cookies из футера
    const handleOpenPreferences = () => {
      setShowPreferences(true)
    }

    window.addEventListener('openCookiePreferences', handleOpenPreferences)

    return () => {
      window.removeEventListener('openCookiePreferences', handleOpenPreferences)
    }
  }, [])

  const applyConsent = (prefs: CookiePreferences) => {
    // Essential cookies всегда активны
    
    // Инициализируем GTM только после получения согласия
    if (prefs.analytics || prefs.marketing || prefs.functional) {
      initializeGTM(prefs)
    }
    
    // Отправляем событие согласия
    sendConsentEvent(prefs)
  }



  const handleAcceptAll = () => {
    const allAccepted = {
      essential: true,
      analytics: true,
      marketing: true,
      functional: true
    }
    setPreferences(allAccepted)
    localStorage.setItem('cookie-consent', JSON.stringify(allAccepted))
    setShowBanner(false)
    applyConsent(allAccepted)
  }

  const handleDecline = () => {
    const onlyEssential = {
      essential: true,
      analytics: false,
      marketing: false,
      functional: false
    }
    setPreferences(onlyEssential)
    localStorage.setItem('cookie-consent', JSON.stringify(onlyEssential))
    setShowBanner(false)
    applyConsent(onlyEssential)
  }

  const handleSavePreferences = () => {
    localStorage.setItem('cookie-consent', JSON.stringify(preferences))
    setShowPreferences(false)
    setShowBanner(false)
    applyConsent(preferences)
  }

  const handlePreferencesChange = (type: keyof CookiePreferences) => {
    if (type === 'essential') return // Essential всегда true
    setPreferences(prev => ({
      ...prev,
      [type]: !prev[type]
    }))
  }

  if (!showBanner && !showPreferences) return null

  if (showPreferences) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-3">
                <Settings className="text-blue-600" size={24} />
                {translations.preferencesTitle}
              </h2>
              <button
                onClick={() => setShowPreferences(false)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              >
                <X size={24} />
              </button>
            </div>

            <div className="space-y-6">
              {/* Essential Cookies */}
              <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                <div className="flex items-center gap-3 mb-3">
                  <CheckCircle className="text-green-600" size={20} />
                  <h3 className="font-semibold text-gray-900 dark:text-white">{translations.essential}</h3>
                  <span className="px-2 py-1 text-xs bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 rounded-full">
                    {translations.alwaysActive}
                  </span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {translations.essentialDesc}
                </p>
              </div>

              {/* Analytics Cookies */}
              <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                <div className="flex items-center gap-3 mb-3">
                  <Info className="text-blue-600" size={20} />
                  <h3 className="font-semibold text-gray-900 dark:text-white">{translations.analytics}</h3>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={preferences.analytics}
                      onChange={() => handlePreferencesChange('analytics')}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                  </label>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {translations.analyticsDesc}
                </p>
              </div>

              {/* Marketing Cookies */}
              <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                <div className="flex items-center gap-3 mb-3">
                  <AlertTriangle className="text-orange-600" size={20} />
                  <h3 className="font-semibold text-gray-900 dark:text-white">{translations.marketing}</h3>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={preferences.marketing}
                      onChange={() => handlePreferencesChange('marketing')}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                  </label>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {translations.marketingDesc}
                </p>
              </div>

              {/* Functional Cookies */}
              <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                <div className="flex items-center gap-3 mb-3">
                  <Info className="text-purple-600" size={20} />
                  <h3 className="font-semibold text-gray-900 dark:text-white">{translations.functional}</h3>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={preferences.functional}
                      onChange={() => handlePreferencesChange('functional')}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                  </label>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {translations.functionalDesc}
                </p>
              </div>
            </div>

            <div className="flex gap-3 mt-8">
              <button
                onClick={handleSavePreferences}
                className="flex-1 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
              >
                {translations.savePreferences}
              </button>
              <button
                onClick={() => setShowPreferences(false)}
                className="px-6 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg font-medium hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                {translations.cancel}
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 shadow-2xl z-40">
      <div className="max-w-7xl mx-auto p-4">
        <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
          <div className="flex items-start gap-3 flex-1">
            <Cookie className="text-blue-600 mt-1" size={24} />
            <div className="flex-1">
              <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                {translations.title}
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {translations.description}
              </p>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
            <button
              onClick={handleAcceptAll}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
            >
              {translations.acceptAll}
            </button>
            <button
              onClick={handleDecline}
              className="px-6 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg font-medium hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              {translations.decline}
            </button>
            <button
              onClick={() => setShowPreferences(true)}
              className="px-6 py-3 text-blue-600 hover:text-blue-700 font-medium transition-colors"
            >
              {translations.preferences}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
