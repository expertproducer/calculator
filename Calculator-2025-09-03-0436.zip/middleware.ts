import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

// Keep in sync with next.config.js i18n.locales
const locales = ['en', 'de', 'fr', 'es'] as const
const defaultLocale = 'en'

// Middleware for locale redirects and domain handling
export function middleware(request: NextRequest) {
  const pathname = request.nextUrl.pathname
  const hostname = request.nextUrl.hostname
  
  // Skip static files and API routes
  if (pathname.startsWith('/_next') || 
      pathname.startsWith('/api') || 
      pathname.startsWith('/images') ||
      pathname.startsWith('/favicon') ||
      pathname.includes('.')) {
    return
  }
  
  // Handle www redirects
  if (hostname.startsWith('www.')) {
    const newHostname = hostname.replace('www.', '')
    const newUrl = new URL(request.url)
    newUrl.hostname = newHostname
    return NextResponse.redirect(newUrl, 301)
  }
  
  // Check if the pathname has a locale
  const pathnameHasLocale = locales.some(
    (locale) => pathname.startsWith(`/${locale}/`) || pathname === `/${locale}`
  )

  if (pathnameHasLocale) return

  // Redirect if there is no locale
  const locale = defaultLocale
  return NextResponse.redirect(
    new URL(`/${locale}${pathname}`, request.url)
  )
}

export const config = {
  matcher: [
    // Skip all internal paths (_next)
    '/((?!_next|api|favicon.ico).*)',
  ],
}
