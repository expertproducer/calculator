export default function TestPage() {
  return (
    <div style={{ padding: '20px' }}>
      <h1>Test Page</h1>
      <p>If you can see this, the server is working fine!</p>
      <a href="/en/">Go to English version</a><br/>
      <a href="/de/">Go to German version</a><br/>
      <a href="/fr/">Go to French version</a>
    </div>
  )
}
